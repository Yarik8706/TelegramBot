import logging
from aiogram import Bot, Dispatcher, types, executor
import config
import openai

logging.basicConfig(level=logging.INFO)

bot = Bot(config.TELEGRAMBOTTOKEN)
dp = Dispatcher(bot)
history = []

openai.api_key = config.OPENAITOKEN

start_sequence = "\nAI:"
restart_sequence = "\nHuman: "


@dp.message_handler()
async def echo(message: types.Message):
    history.append(restart_sequence+message.text)
    text = create_AI_responce()
    history.append(start_sequence+text)
    await message.answer(text)


def create_AI_responce():
    res = openai.Completion.create(
        model="text-davinci-003",
        prompt=f"The following is a conversation with an AI assistant. The assistant is helpful, creative, clever, and very friendly.\n" + "".join(history) + "\nHuman: {answer}\nAI:",
        temperature=0.9,
        max_tokens=600,
        top_p=1,
        frequency_penalty=0,
        presence_penalty=0.6,
        stop=[" Human:", " AI:"]
    )
    return res["choices"][0]["text"]


if __name__ == "__main__":
    executor.start_polling(dp, skip_updates=False)